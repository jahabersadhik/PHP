<div id="footer" class="clearfix">
    	<div class="footer_content">Copyright &copy; 2010 <span class="orange">PERI</span>. All rights reserved. </div>
    </div>
